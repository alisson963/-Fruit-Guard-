"""Visao computacional local. Nao acessa memoria/API interna do jogo."""
import heapq
import math
from dataclasses import dataclass
import cv2
import numpy as np

@dataclass
class Fruit:
    x: int
    y: int
    kind: str
    score: float

class Arena:
    """Zona permitida conservadora; apos pan de camera deslocar junto com a cena."""
    def __init__(self, polygon, obstacles=(), margin=34, width=1919, height=1079):
        self.polygon = np.asarray(polygon, dtype=np.float32).reshape(-1, 2)
        self.obstacles = [np.asarray(r, dtype=np.float32).reshape(-1,2) for r in obstacles]
        self.margin = max(12, int(margin))
        self.size = (int(width), int(height))
        self._mask = None

    def scale_to(self, width, height):
        if self.size != (width, height):
            sx, sy = width/self.size[0], height/self.size[1]
            self.polygon *= (sx,sy)
            for ob in self.obstacles: ob *= (sx,sy)
            self.margin = int(round(self.margin*(sx+sy)/2))
            self.size=(width,height)
            self._mask=None

    def shift(self, dx, dy):
        if abs(dx)<.2 and abs(dy)<.2: return
        self.polygon += (dx,dy)
        for ob in self.obstacles: ob += (dx,dy)
        self._mask = None

    def safe_mask(self):
        if self._mask is not None: return self._mask
        w,h=self.size
        field = np.zeros((h,w),dtype=np.uint8)
        cv2.fillPoly(field,[np.rint(self.polygon).astype(np.int32)],255)
        rad=max(3,int(self.margin))
        kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(rad*2+1,rad*2+1))
        field=cv2.erode(field,kernel)
        for ob in self.obstacles:
            m=np.zeros_like(field)
            cv2.fillPoly(m,[np.rint(ob).astype(np.int32)],255)
            r=max(5,int(self.margin*.45))
            k=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*r+1,2*r+1))
            m=cv2.dilate(m,k)
            field[m>0]=0
        self._mask=field
        return field

    def contains(self,x,y):
        h,w=self.safe_mask().shape
        xi,yi=int(round(x)),int(round(y))
        return (0<=xi<w and 0<=yi<h and self._mask[yi,xi]>0)

    def line_is_safe(self,a,b):
        distance=math.dist(a,b)
        n=max(2,int(distance/7)+1)
        return all(self.contains(a[0]+(b[0]-a[0])*i/n,a[1]+(b[1]-a[1])*i/n) for i in range(n+1))

class FruitDetector:
    HUES={
        'rosa':[(162,179)],
        'verde':[(35,82)],
        'azul':[(84,107)],
    }
    def detect(self,frame,arena,player=None):
        hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        valid=arena.safe_mask()
        h,w=frame.shape[:2]
        f=(h/1079+w/1919)/2
        result=[]
        for label,ranges in self.HUES.items():
            mask=np.zeros((h,w),dtype=np.uint8)
            for lo,hi in ranges:
                mask=cv2.bitwise_or(mask,cv2.inRange(hsv,(lo,134,100),(hi,255,255)))
            mask=cv2.bitwise_and(mask,valid)
            mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)))
            contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            for c in contours:
                x,y,bw,bh=cv2.boundingRect(c)
                area=cv2.contourArea(c)
                if not (11*f<=bw<=35*f and 11*f<=bh<=35*f): continue
                if not (40*f*f<=area<=680*f*f): continue
                if bw/bh <.63 or bw/bh>1.50: continue
                # Rejeita linhas de interface, cantos retos e fragmentos de terreno.
                density=area/(bw*bh)
                if density < .20 or density>.94: continue
                cx=x+bw/2;cy=y+bh/2
                if not arena.contains(cx,cy): continue
                if player is not None and math.dist((cx,cy),player) < 37*f: continue
                confidence = min(1.,density/.55)*min(1.,area/(165*f*f))
                result.append(Fruit(int(round(cx)),int(round(cy)),label,confidence))
        # Mesma fruta, multipla faixa de cor / pequenos componentes proximos.
        final=[]
        for fr in sorted(result,key=lambda t:-t.score):
            if all(math.dist((fr.x,fr.y),(old.x,old.y))>20*f for old in final):final.append(fr)
        return sorted(final,key=lambda fr:(fr.y,fr.x))

class PlayerTracker:
    """Rastreia sprite com mais de um template, mantendo a busca perto da última posição.

    Usar somente uma imagem rígida faz o rastreio falhar no primeiro frame em que
    a animação da caminhada muda. Os templates adicionais são aceitos apenas
    em correspondências de alta confiança e não substituem o original.
    """
    def __init__(self, frame, center, radius=25):
        self.radius=radius
        self.pos=(float(center[0]),float(center[1]))
        x,y=int(center[0]),int(center[1]);h,w=frame.shape[:2]
        if x-radius<0 or y-radius<0 or x+radius>=w or y+radius>=h:
            raise ValueError('Personagem proximo demais da borda da tela')
        self.templates=[frame[y-radius:y+radius,x-radius:x+radius].copy()]
        self.confidence=1.
        self.lost_frames=0
        self._template_age=0

    def locate(self, frame, expected_shift=(0.,0.), search_radius=125):
        h,w=frame.shape[:2];r=self.radius
        cx=int(round(self.pos[0]+expected_shift[0]))
        cy=int(round(self.pos[1]+expected_shift[1]))
        x1=max(0,cx-r-search_radius);x2=min(w,cx+r+search_radius)
        y1=max(0,cy-r-search_radius);y2=min(h,cy+r+search_radius)
        scene=frame[y1:y2,x1:x2]
        if scene.shape[0]<r*2 or scene.shape[1]<r*2:return None,0.
        best=(-1.,None,None)
        for tid,template in enumerate(self.templates):
            match=cv2.matchTemplate(scene,template,cv2.TM_CCOEFF_NORMED)
            _,score,_,loc=cv2.minMaxLoc(match)
            if not np.isfinite(score):continue
            pos=(float(x1+loc[0]+r),float(y1+loc[1]+r))
            # Penaliza saltos grandes: elementos coloridos do chao podem parecer o avatar.
            distance=math.dist(pos,(cx,cy))
            reliability=score-max(0,distance-35)*.0011
            if reliability>best[0]:best=(reliability,(float(score),pos),tid)
        _,result,tid=best
        if result is None:return None,0.
        score,pos=result
        distance=math.dist(pos,(cx,cy))
        threshold=.39 if distance<=25 else (.44 if distance<=60 else .52)
        if score < threshold or distance>search_radius+4:
            self.lost_frames+=1
            return None,float(score)
        self.lost_frames=0
        self.pos=pos;self.confidence=float(score)
        if score>.72 and tid is not None:
            self._template_age+=1
            if self._template_age>=4 and len(self.templates)<4:
                xx,yy=map(lambda x:int(round(x)),pos)
                if xx-r>=0 and yy-r>=0 and xx+r<w and yy+r<h:
                    self.templates.append(frame[yy-r:yy+r,xx-r:xx+r].copy())
                    self._template_age=0
        return self.pos,self.confidence

class SceneShift:
    """Estima pan de camera pelas texturas da arena, nao pela posicao da HUD."""
    def __init__(self):self.previous=None;self.box=None
    def update(self,frame,arena):
        if self.box is None:
            p=arena.polygon
            h,w=frame.shape[:2]
            x1=max(0,int(np.min(p[:,0]))); y1=max(0,int(np.min(p[:,1])))
            x2=min(w,int(np.max(p[:,0]))); y2=min(h,int(np.max(p[:,1])))
            self.box=(x1,y1,x2,y2)
        x1,y1,x2,y2=self.box
        gray=cv2.cvtColor(frame[y1:y2,x1:x2],cv2.COLOR_BGR2GRAY)
        # A textura pontilhada do chao do jogo e periodica: borrá-la antes da
        # correlacao escondia o deslocamento da camera. Bordas preservam cercas.
        gray=cv2.Canny(gray,38,125)
        gray=cv2.resize(gray,None,fx=.40,fy=.40,interpolation=cv2.INTER_AREA).astype(np.float32)
        if self.previous is None:
            self.previous=gray;return (0.,0.),1.
        if gray.shape!=self.previous.shape:
            self.previous=gray;return (0.,0.),0.
        shift,response=cv2.phaseCorrelate(self.previous,gray)
        self.previous=gray
        dx,dy=shift[0]/.4,shift[1]/.4
        if not (np.isfinite(dx) and np.isfinite(dy) and np.isfinite(response)):
            return (0.,0.),0.
        if abs(dx)>115 or abs(dy)>115: return (0.,0.),0.
        return ((float(dx),float(dy)) if response>.17 else (0.,0.)),float(response)

def find_path(arena,start,goal,cell=24):
    """A* em grade para contornar barreiras internas."""
    if not arena.contains(*start) or not arena.contains(*goal):return None
    poly=arena.polygon
    xmin=max(0,int(np.min(poly[:,0]))-cell);ymin=max(0,int(np.min(poly[:,1]))-cell)
    xmax=min(arena.size[0]-1,int(np.max(poly[:,0]))+cell)
    ymax=min(arena.size[1]-1,int(np.max(poly[:,1]))+cell)
    nx=int((xmax-xmin)//cell)+1;ny=int((ymax-ymin)//cell)+1
    def center(ix,iy):return (xmin+ix*cell,ymin+iy*cell)
    def nearest(pt):
        x=int(round((pt[0]-xmin)/cell)); y=int(round((pt[1]-ymin)/cell))
        candidates=[]
        for radius in range(4):
            for dx in range(-radius,radius+1):
                for dy in range(-radius,radius+1):
                    ix=x+dx;iy=y+dy
                    if 0<=ix<nx and 0<=iy<ny and arena.contains(*center(ix,iy)):
                        candidates.append((math.dist(pt,center(ix,iy)),(ix,iy)))
            if candidates: break
        return min(candidates)[1] if candidates else None
    beg=nearest(start);end=nearest(goal)
    if not beg or not end: return None
    if beg==end:return [start,goal]
    directions=[(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
    q=[(0,0,beg)]; distances={beg:0.}; parents={};visited=set();tiebreak=0
    while q and len(visited)<4500:
        _,_,node=heapq.heappop(q)
        if node in visited:continue
        visited.add(node)
        if node==end:
            seq=[end]
            while seq[-1]!=beg:seq.append(parents[seq[-1]])
            seq.reverse()
            return [start]+[center(*p) for p in seq[1:-1]]+[goal]
        x,y=node
        for dx,dy in directions:
            nxt=(x+dx,y+dy)
            if not (0<=nxt[0]<nx and 0<=nxt[1]<ny):continue
            if not arena.contains(*center(*nxt)):continue
            if dx and dy and (not arena.contains(*center(x+dx,y)) or not arena.contains(*center(x,y+dy))):continue
            cost=distances[node]+math.hypot(dx,dy)
            if cost>=distances.get(nxt,1e50):continue
            distances[nxt]=cost;parents[nxt]=node;tiebreak+=1
            h=math.dist(nxt,end)
            heapq.heappush(q,(cost+h,tiebreak,nxt))
    return None

def select_target(arena,player,fruits,ignore=()):
    candidates=sorted((f for f in fruits
                       if arena.contains(f.x,f.y) and
                       all(math.dist((f.x,f.y),pt)>30 for pt in ignore)),
                      key=lambda f:math.dist(player,(f.x,f.y)))
    best=None
    # Tenta ate as 7 mais proximas: primeiro destino alcancavel.
    for fr in candidates[:7]:
        path=find_path(arena,player,(fr.x,fr.y))
        if not path:continue
        dist=sum(math.dist(a,b) for a,b in zip(path,path[1:]))
        if best is None or dist<best[0]:best=(dist,fr,path)
    return None if best is None else (best[1],best[2])

def waypoint(path,player,distance=75):
    # Avanca ate no maximo 75px ao longo da rota, sem cortar pelo obstaculo.
    origin=player
    walked=0.
    for p in path[1:]:
        seg=math.dist(origin,p)
        if walked+seg>=distance and seg>0:
            t=(distance-walked)/seg
            return (origin[0]+(p[0]-origin[0])*t,origin[1]+(p[1]-origin[1])*t)
        walked+=seg
        origin=p
    return path[-1]

def choose_key(arena,player,goal,vw,vd,dt):
    directions={'W':vw, 'S':(-vw[0],-vw[1]),'D':vd,'A':(-vd[0],-vd[1])}
    here=np.asarray(player,dtype=float)
    target=np.asarray(goal,dtype=float)
    choices=[]
    for key,velocity in directions.items():
        delta=np.asarray(velocity,dtype=float)*dt
        new=here+delta
        if not arena.line_is_safe(here,new):continue
        if math.hypot(*delta)<1.1:continue
        gain=float(np.linalg.norm(target-here)-np.linalg.norm(target-new))
        choices.append((gain,key,(float(new[0]),float(new[1]))))
    if not choices:return None
    gain,key,predicted=max(choices)
    return (key,predicted) if gain>0.8 else None

def choose_action(arena, player, goal, vw, vd, max_dt, min_dt=.07):
    """Seleciona um movimento cardinal/diagonal, com duracao e caminho seguros.

    Prefere um passo mais longo quando livre, mas reduz o tempo perto de cercas,
    obstaculos, curvas e alvos. Nenhum movimento que cruze o limite é permitido.
    """
    directions={
        ('W',):np.asarray(vw,dtype=float),
        ('S',):-np.asarray(vw,dtype=float),
        ('D',):np.asarray(vd,dtype=float),
        ('A',):-np.asarray(vd,dtype=float),
    }
    for a in ('W','S'):
        for b in ('A','D'):
            directions[(a,b)]=(directions[(a,)]+directions[(b,)])/math.sqrt(2.)
    here=np.asarray(player,dtype=float)
    target=np.asarray(goal,dtype=float)
    remaining=float(np.linalg.norm(target-here))
    if remaining<3:return None
    speed=max(float(np.linalg.norm(v)) for v in directions.values())
    if speed<10:return None
    # Evita passar do alvo e aumenta a duração em trajetos abertos.
    preferred=min(max_dt,max(min_dt,remaining/max(speed,1)*.85))
    durations=[preferred,preferred*.78,preferred*.58,preferred*.4,min_dt]
    durations=sorted({round(max(min_dt,d),3) for d in durations},reverse=True)
    moves=[]
    for keys,velocity in directions.items():
        for dt in durations:
            candidate=here+velocity*dt
            if not arena.line_is_safe(here,candidate):continue
            # Tolerancia caso o servidor mova ligeiramente mais do que a
            # velocidade aprendida: nao encosta nas cercas por aproximacao.
            extended=here+(candidate-here)*1.23
            if not arena.line_is_safe(here,extended):continue
            after=float(np.linalg.norm(target-candidate))
            gain=remaining-after
            if gain < max(.45, speed*dt*.09): continue
            # privilegia trajetória que reduz distância e não zig-zag
            score=gain-(.05 if len(keys)==2 else 0)
            moves.append((score,dt,keys,(float(candidate[0]),float(candidate[1]))))
    if not moves:return None
    score,dt,keys,prediction=max(moves,key=lambda m:(m[0],m[1]))
    return keys,dt,prediction

def draw_overlay(frame,arena=None,fruits=(),player=None,target=None,path=None,status=''):
    image=frame.copy()
    if arena:
        cv2.polylines(image,[np.rint(arena.polygon).astype(np.int32)],True,(0,255,255),3)
        for ob in arena.obstacles:
            pts=np.rint(ob).astype(np.int32)
            cv2.polylines(image,[pts],True,(30,50,255),3)
        safe=arena.safe_mask()
        border=cv2.Canny(safe,50,150)
        image[border>0]=(20,210,20)
    for fr in fruits:
        color={'rosa':(190,30,255),'verde':(0,255,80),'azul':(255,255,0)}[fr.kind]
        cv2.circle(image,(fr.x,fr.y),19,color,2)
        cv2.putText(image,fr.kind,(fr.x+16,fr.y-10),cv2.FONT_HERSHEY_SIMPLEX,.45,color,1,cv2.LINE_AA)
    if player is not None:
        p=(int(player[0]),int(player[1]))
        cv2.circle(image,p,33,(255,210,0),3)
        cv2.drawMarker(image,p,(255,210,0),cv2.MARKER_CROSS,22,2)
    if path:
        arr=np.array([list(map(int,p)) for p in path],dtype=np.int32)
        cv2.polylines(image,[arr],False,(255,240,90),3)
    if target:
        cv2.circle(image,(target.x,target.y),26,(0,165,255),4)
        cv2.putText(image,'ALVO',(target.x-25,target.y-34),cv2.FONT_HERSHEY_SIMPLEX,.7,(0,165,255),2,cv2.LINE_AA)
    if status:cv2.putText(image,status,(25,image.shape[0]-30),cv2.FONT_HERSHEY_SIMPLEX,.85,(255,255,255),3,cv2.LINE_AA)
    return image
