"""Interface de desktop: Cacador de Frutinhas - Roblox.

Controles:
F6 = capturar tela atual (com Roblox em primeiro plano)
F7 = iniciar movimentos (com Roblox em primeiro plano)
F8 = parar, soltando WASD
"""
import json
import os
import queue
import sys
import time
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from pathlib import Path

import cv2
import numpy as np
from PIL import Image,ImageTk
from vision import Arena,FruitDetector,draw_overlay,select_target
from engine import Engine
from controller import Screen,GameKeys

ROOT=Path(__file__).resolve().parent
CFG=ROOT/'calibracao.json'
SNAP=ROOT/'calibracao.png'
DEMO=ROOT/'exemplos'/'print_original.png'
DEFAULT={
 'width':1919,'height':1079,
 'polygon':[[685,282],[1275,282],[1330,880],[645,880]],
 'player':[960,547],
 'obstacles':[[[881,581],[1080,581],[1080,905],[881,905]]],
 'margin':34,'step':0.275,'auto_calibrate':True,'input_mode':'scan'
}

BG='#111827';PANEL='#1c2635';BORDER='#334155';TEXT='#edf2f7';SUB='#a8bbcc'
ACCENT='#f59e0b';GREEN='#34d399';RED='#fb7185'

class Application:
    def __init__(self,root):
        self.root=root
        self.root.title('FRUIT GUARD V2 • Caminhada contínua Roblox')
        self.root.geometry('1390x870')
        self.root.minsize(1130,730)
        self.root.configure(bg=BG)
        self.events=queue.Queue(maxsize=12)
        self.engine=None
        self.frame=None
        self.last_canvas_frame=None
        self.canvas_photo=None
        self.canvas_transform=(0,0,1.)
        self.mode=None
        self.clicks=[]
        self.result=[]
        self.target_path=None
        self.config=self._load_config()
        # Configuracoes de 100ms da V1 ficavam curtas demais no Roblox.
        if self.config.get('step',0) < .18:
            self.config['step']=.275
        self.status=tk.StringVar(value='PARADO • Pronto para calibrar')
        self.counter=tk.StringVar(value='— frutas')
        self.coordinates=tk.StringVar(value='Sem rastreamento')
        self.auto=tk.BooleanVar(value=self.config.get('auto_calibrate',True))
        self.input_mode=tk.StringVar(value=self.config.get('input_mode','scan'))
        self.margin=tk.IntVar(value=self.config.get('margin',34))
        self.step=tk.IntVar(value=max(150,int(self.config.get('step',.275)*1000)))
        self._last_keys={key:False for key in (0x75,0x76,0x77)}
        self._build()
        saved=cv2.imread(str(SNAP)) if SNAP.exists() else None
        if saved is None:
            saved=cv2.imread(str(DEMO))
            self._log('Abrindo exemplo fornecido. CAPTURE O JOGO AO VIVO antes de iniciar.')
        else:self._log('Calibracao anterior carregada.')
        self._set_frame(saved)
        self.root.after(70,self._tick)

    def _load_config(self):
        if CFG.exists():
            try:
                data=json.loads(CFG.read_text(encoding='utf-8'))
                if all(k in data for k in ('polygon','player','width','height')):return data
            except Exception:pass
        return json.loads(json.dumps(DEFAULT))

    def _build(self):
        top=tk.Frame(self.root,bg=BG)
        top.pack(fill='x',padx=20,pady=(15,9))
        tk.Label(top,text='🍎  FRUIT GUARD V2',bg=BG,fg=ACCENT,font=('Segoe UI',23,'bold')).pack(side='left')
        tk.Label(top,text='Roblox  •  coletor automático dentro do cercado',bg=BG,fg=SUB,font=('Segoe UI',11)).pack(side='left',padx=20,pady=12)
        self.pill=tk.Label(top,text='●  DESLIGADO',bg='#263447',fg=SUB,font=('Segoe UI',11,'bold'),padx=14,pady=6)
        self.pill.pack(side='right')

        body=tk.Frame(self.root,bg=BG)
        body.pack(fill='both',expand=True,padx=17,pady=3)
        left=tk.Frame(body,bg=PANEL,highlightbackground=BORDER,highlightthickness=1)
        left.pack(side='left',fill='both',expand=True,padx=(0,13))
        # Painel rolavel: a resolucao de 1366x768 nao deve esconder controles.
        right_outer=tk.Frame(body,bg=BG,width=370)
        right_outer.pack(side='right',fill='y');right_outer.pack_propagate(False)
        right_scroll=tk.Scrollbar(right_outer,orient='vertical')
        right_scroll.pack(side='right',fill='y')
        right_canvas=tk.Canvas(right_outer,bg=BG,bd=0,highlightthickness=0,
                               yscrollcommand=right_scroll.set)
        right_canvas.pack(side='left',fill='both',expand=True)
        right_scroll.configure(command=right_canvas.yview)
        right=tk.Frame(right_canvas,bg=BG)
        window_id=right_canvas.create_window((0,0),window=right,anchor='nw')
        right.bind('<Configure>',lambda e:right_canvas.configure(scrollregion=right_canvas.bbox('all')))
        right_canvas.bind('<Configure>',lambda e:right_canvas.itemconfigure(window_id,width=e.width))
        def scroll(event):
            widget=event.widget
            inside=False
            while widget is not None:
                if widget is right_canvas or widget is right:
                    inside=True;break
                widget=getattr(widget,'master',None)
            if inside and event.delta:
                right_canvas.yview_scroll(-int(event.delta/120),'units')
        self.root.bind_all('<MouseWheel>',scroll)
        header=tk.Frame(left,bg=PANEL);header.pack(fill='x',padx=15,pady=(14,8))
        tk.Label(header,text='VISÃO DO JOGO',font=('Segoe UI',13,'bold'),bg=PANEL,fg=TEXT).pack(side='left')
        tk.Label(header,textvariable=self.counter,font=('Segoe UI',10,'bold'),bg=PANEL,fg=GREEN).pack(side='right')
        self.canvas=tk.Canvas(left,bg='#070e18',highlightthickness=0,cursor='crosshair')
        self.canvas.pack(fill='both',expand=True,padx=10,pady=5)
        self.canvas.bind('<Button-1>',self._click_canvas)
        self.canvas.bind('<Configure>',lambda e:self._redraw())
        legend=tk.Frame(left,bg=PANEL);legend.pack(fill='x',padx=14,pady=(5,12))
        tk.Label(legend,text='AMARELO: cerca  •  VERDE: zona segura  •  VERMELHO: obstáculos  •  CÍRCULOS: frutas  •  AZUL: personagem',font=('Segoe UI',9),bg=PANEL,fg=SUB,wraplength=780).pack(anchor='w')

        self._section(right,'CONTROLE')
        panel=tk.Frame(right,bg=PANEL,padx=13,pady=12);panel.pack(fill='x',pady=(0,10))
        self._button(panel,'▶  INICIAR COLETA  [F7]',self._start, GREEN, dark=True).pack(fill='x',pady=(0,9))
        self._button(panel,'■  PARAR E SOLTAR TECLAS  [F8]',self._stop, '#b91c1c').pack(fill='x')
        tk.Label(panel,textvariable=self.status,bg=PANEL,fg=TEXT,font=('Segoe UI',9),wraplength=310,justify='left').pack(anchor='w',pady=(12,3))
        tk.Label(panel,textvariable=self.coordinates,bg=PANEL,fg=SUB,font=('Segoe UI',9)).pack(anchor='w')
        tk.Label(panel,text='F7/F8 funcionam com o jogo na frente.',bg=PANEL,fg=SUB,font=('Segoe UI',9)).pack(anchor='w',pady=(6,0))

        self._section(right,'CALIBRAR A TELA')
        p=tk.Frame(right,bg=PANEL,padx=13,pady=13);p.pack(fill='x',pady=(0,10))
        self._button(p,'📸  Capturar Roblox  [F6]',self._capture_delayed,BORDER).pack(fill='x',pady=(0,6))
        self._button(p,'Abrir imagem para teste',self._open_image,BORDER).pack(fill='x',pady=(0,8))
        b=tk.Frame(p,bg=PANEL);b.pack(fill='x')
        self._button(b,'1. Cerca (4 cliques)',lambda:self._mode('polygon'),BORDER).pack(side='left',fill='x',expand=True,padx=(0,4))
        self._button(b,'2. Personagem',lambda:self._mode('player'),BORDER).pack(side='left',fill='x',expand=True)
        b2=tk.Frame(p,bg=PANEL);b2.pack(fill='x',pady=(6,0))
        self._button(b2,'3. Obstáculo (4 cliques)',lambda:self._mode('obstacle'),BORDER).pack(side='left',fill='x',expand=True,padx=(0,4))
        self._button(b2,'Limpar obstáculos',self._clear_obstacles,BORDER).pack(side='left',fill='x',expand=True)
        self._button(p,'💾  Salvar calibração',self._save,ACCENT,dark=True).pack(fill='x',pady=(9,0))
        tk.Label(p,text='Marque cada ponto clicando na imagem à esquerda.',bg=PANEL,fg=SUB,font=('Segoe UI',9)).pack(anchor='w',pady=(6,0))

        self._section(right,'MOVIMENTO E PROTEÇÕES')
        p=tk.Frame(right,bg=PANEL,padx=14,pady=12);p.pack(fill='x',pady=(0,10))
        tk.Checkbutton(p,text='Calibrar WASD automaticamente',variable=self.auto,bg=PANEL,fg=TEXT,selectcolor=BORDER,activebackground=PANEL,activeforeground=TEXT,font=('Segoe UI',10)).pack(anchor='w')
        tk.Label(p,text='O bot recalcula o caminho após cada passo e permite diagonais.',bg=PANEL,fg=GREEN,font=('Segoe UI',9),wraplength=316,justify='left').pack(anchor='w',pady=(5,2))
        tk.Label(p,text='Margem interna de segurança (pixels):',bg=PANEL,fg=SUB,font=('Segoe UI',9)).pack(anchor='w',pady=(10,0))
        tk.Scale(p,variable=self.margin,from_=22,to=90,orient='horizontal',bg=PANEL,fg=TEXT,troughcolor=BORDER,highlightthickness=0,showvalue=True,resolution=2,command=lambda *_:self._redraw()).pack(fill='x')
        tk.Label(p,text='Movimento contínuo: duração máxima do passo (ms):',bg=PANEL,fg=SUB,font=('Segoe UI',9)).pack(anchor='w',pady=(8,0))
        tk.Scale(p,variable=self.step,from_=150,to=420,orient='horizontal',bg=PANEL,fg=TEXT,troughcolor=BORDER,highlightthickness=0,resolution=5).pack(fill='x')
        row_keys=tk.Frame(p,bg=PANEL);row_keys.pack(fill='x',pady=(5,0))
        tk.Label(row_keys,text='Teclado:',bg=PANEL,fg=SUB,font=('Segoe UI',9)).pack(side='left')
        tk.OptionMenu(row_keys,self.input_mode,'scan','vk').pack(side='left',padx=8)
        tk.Label(row_keys,text='scan = padrao • vk = alternativa',bg=PANEL,fg=SUB,font=('Segoe UI',8)).pack(side='left')
        self._button(p,'🔎  Detectar frutas agora',self._detect,ACCENT,dark=True).pack(fill='x',pady=(8,0))

        self._section(right,'DIAGNÓSTICO')
        self.log_box=tk.Text(right,height=6,bg='#0b111d',fg=SUB,insertbackground=TEXT,font=('Consolas',9),relief='flat',wrap='word')
        self.log_box.pack(fill='both',expand=True,pady=(0,5))
        self.log_box.configure(state='disabled')
        tk.Label(self.root,text='O bot só envia WASD ao Roblox Player. Perdeu a referência, o foco ou a margem segura? PARA.  •  F8: emergência.',bg=BG,fg=SUB,font=('Segoe UI',9)).pack(fill='x',pady=(4,10))

    def _section(self,parent,title):
        tk.Label(parent,text=title,bg=BG,fg=SUB,font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(2,6))

    def _button(self,parent,text,command,color,dark=False):
        fg='#10232a' if dark else '#f8fafc'
        b=tk.Button(parent,text=text,command=command,bg=color,fg=fg,activebackground=color,activeforeground=fg,font=('Segoe UI',9,'bold'),relief='flat',bd=0,padx=8,pady=8,cursor='hand2')
        return b

    def _log(self,msg):
        if not hasattr(self,'log_box'):return
        self.log_box.configure(state='normal')
        self.log_box.insert('end',time.strftime('%H:%M:%S  ')+str(msg)+'\n')
        self.log_box.see('end');self.log_box.configure(state='disabled')

    def _set_frame(self,frame):
        if frame is None:return
        h,w=frame.shape[:2]
        oldw,oldh=self.config['width'],self.config['height']
        if (oldw,oldh)!=(w,h):
            sx,sy=w/oldw,h/oldh
            self.config['polygon']=[[round(p[0]*sx),round(p[1]*sy)] for p in self.config['polygon']]
            self.config['player']=[round(self.config['player'][0]*sx),round(self.config['player'][1]*sy)]
            self.config['obstacles']=[[[round(p[0]*sx),round(p[1]*sy)] for p in poly] for poly in self.config.get('obstacles',[])]
            self.config['width']=w;self.config['height']=h
        self.frame=frame
        self.last_canvas_frame=None
        self._redraw()

    def _get_arena(self):
        if self.frame is None:return None
        h,w=self.frame.shape[:2]
        c=self.config
        arena=Arena(c['polygon'],c.get('obstacles',[]),self.margin.get(),c['width'],c['height'])
        arena.scale_to(w,h)
        return arena

    def _redraw(self):
        if not hasattr(self,'canvas') or self.frame is None:return
        c=self.canvas
        cw,ch=c.winfo_width(),c.winfo_height()
        if cw<=10 or ch<=10:return
        base=self.last_canvas_frame if self.last_canvas_frame is not None else self.frame
        if self.last_canvas_frame is None:
            try:
                arena=self._get_arena();
                h,w=self.frame.shape[:2]
                orig=np.asarray(self.config['player'],dtype=float)*[w/self.config['width'],h/self.config['height']]
                base=draw_overlay(self.frame,arena,self.result,orig,self.target_path[0] if self.target_path else None,self.target_path[1] if self.target_path else None)
            except Exception:base=self.frame
        h,w=base.shape[:2]
        scale=min(cw/w,ch/h)
        neww,maxh=max(1,round(w*scale)),max(1,round(h*scale))
        x=(cw-neww)/2;y=(ch-maxh)/2
        rgb=cv2.cvtColor(base,cv2.COLOR_BGR2RGB)
        image=Image.fromarray(rgb).resize((neww,maxh),Image.Resampling.LANCZOS)
        self.canvas_photo=ImageTk.PhotoImage(image)
        c.delete('all')
        c.create_image(x,y,image=self.canvas_photo,anchor='nw')
        self.canvas_transform=(x,y,scale)
        if self.mode:
            c.create_rectangle(9,9,min(cw-9,470),43,fill='#161e2b',outline='#fbbf24')
            captions={'polygon':'Marque 4 cantos do cercado', 'player':'Clique no personagem','obstacle':'Marque 4 cantos de um obstáculo'}
            c.create_text(18,26,text=captions[self.mode]+'  •  '+str(len(self.clicks))+' selecionado(s)',fill='#fbbf24',anchor='w',font=('Segoe UI',11,'bold'))
            pts=[]
            for px,py in self.clicks:
                xx=x+px*scale;yy=y+py*scale
                pts.extend([xx,yy]);c.create_oval(xx-5,yy-5,xx+5,yy+5,outline='white',width=2)
            if len(pts)>=4:c.create_line(*pts,fill=ACCENT,width=2)

    def _mode(self,name):
        self.mode=name;self.clicks=[]
        self.status.set('Calibrando: '+name)
        self._redraw()

    def _click_canvas(self,event):
        if self.mode is None or self.frame is None:return
        x,y,s=self.canvas_transform
        p=((event.x-x)/s,(event.y-y)/s)
        h,w=self.frame.shape[:2]
        if not (0<=p[0]<w and 0<=p[1]<h):return
        self.clicks.append([round(p[0]),round(p[1])])
        required=1 if self.mode=='player' else 4
        if len(self.clicks)>=required:
            # Sempre salvar coordenadas na resolucao do snapshot atual.
            self.config['width']=w;self.config['height']=h
            if self.mode=='player':
                self.config['player']=self.clicks[0]
                self._log('Personagem marcado em '+str(self.clicks[0]))
            elif self.mode=='polygon':
                self.config['polygon']=self.clicks.copy()
                self._log('Cerca marcada (4 pontos).')
            else:
                self.config.setdefault('obstacles',[]).append(self.clicks.copy())
                self._log('Obstaculo incluido na area proibida.')
            self.mode=None;self.clicks=[];self.last_canvas_frame=None
            self._detect()
        else:self._redraw()

    def _clear_obstacles(self):
        self.config['obstacles']=[]
        self.last_canvas_frame=None
        self._redraw()
        self._log('Obstaculos removidos. Cuidado com a torre do Floor 542!')

    def _detect(self):
        if self.frame is None:return
        try:
            arena=self._get_arena();h,w=self.frame.shape[:2]
            player=(self.config['player'][0]*w/self.config['width'],self.config['player'][1]*h/self.config['height'])
            self.result=FruitDetector().detect(self.frame,arena,player)
            self.target_path=select_target(arena,player,self.result)
            self.last_canvas_frame=None
            self.counter.set('%d frutas detectadas'%len(self.result))
            self._log('%d frutas dentro da área e fora dos obstáculos.'%len(self.result))
            self._redraw()
        except Exception as exc:
            self._log('Falha na detecção: '+str(exc))

    def _open_image(self):
        f=filedialog.askopenfilename(title='Abrir print',filetypes=[('Imagens','*.png *.jpg *.jpeg *.bmp')])
        if not f:return
        frame=cv2.imread(f)
        if frame is None:
            messagebox.showerror('Imagem inválida','Não consegui abrir essa imagem.')
            return
        # Mantem geometria calibrada, adaptando proporcionalmente se mudou resolucao.
        self._set_frame(frame)
        self._detect()
        self._log('Imagem carregada: '+Path(f).name)

    def _capture_delayed(self):
        if self.engine and self.engine.thread and self.engine.thread.is_alive():
            self._log('Pare o bot antes de capturar novamente.');return
        self._log('Ocultando janela para capturar Roblox em 0,6 s...')
        self.root.iconify()
        self.root.after(650, self._capture_now)

    def _capture_now(self,show=True):
        try:
            s=Screen()
            frame=s.grab();s.close()
            self._set_frame(frame)
            self._detect()
            self._log('Tela atual capturada. Marque a cerca e personagem se necessario.')
        except Exception as exc:self._log('Erro ao capturar: '+str(exc))
        if show:self.root.deiconify()

    def _save(self):
        if self.frame is None:return
        self.config['step']=self.step.get()/1000.
        self.config['margin']=self.margin.get()
        self.config['auto_calibrate']=self.auto.get()
        self.config['input_mode']=self.input_mode.get()
        try:
            CFG.write_text(json.dumps(self.config,ensure_ascii=False,indent=2),encoding='utf-8')
            cv2.imwrite(str(SNAP),self.frame)
            self._log('Calibração e imagem salvas. Reinicie com F7 no jogo.')
            self.status.set('Configuração salva')
        except Exception as exc:messagebox.showerror('Falha ao salvar',str(exc))

    def _start(self):
        if self.engine and self.engine.thread and self.engine.thread.is_alive():return
        if self.frame is None:self._log('Capture uma imagem primeiro.');return
        self._save()
        self.events=queue.Queue(maxsize=12)
        def post(item):
            try:
                if self.events.full():self.events.get_nowait()
                self.events.put_nowait(item)
            except Exception:pass
        self.engine=Engine(dict(self.config),self.frame.copy(),post,step=self.step.get()/1000.,auto_calibrate=self.auto.get())
        self.engine.start()
        self.pill.configure(text='●  LIGADO',fg=GREEN)
        self.status.set('Ligado. Reconhecendo o Roblox...')
        self._log('Bot ligado. Parada global: F8.')

    def _stop(self):
        if self.engine:self.engine.stop()
        self.pill.configure(text='●  DESLIGADO',fg=SUB)
        self.status.set('PARADO • Teclas serão liberadas')
        self._log('Parada solicitada (F8).')

    def _tick(self):
        # F6/F7/F8 globais via WinAPI; F8 funciona mesmo em outra janela.
        if os.name=='nt':
            for vk,cb in [(0x75,lambda:self._capture_now(show=False)),(0x76,self._start),(0x77,self._stop)]:
                try:
                    down=GameKeys.key_down(vk)
                    if down and not self._last_keys[vk]:cb()
                    self._last_keys[vk]=down
                except Exception:pass
        for _ in range(9):
            try:item=self.events.get_nowait()
            except queue.Empty:break
            kind=item.get('kind')
            if kind=='frame':
                self.last_canvas_frame=item['frame']
                self._redraw()
            elif kind=='state':
                self.status.set(item['message'])
                self.counter.set('%s frutas vistas • %s passos • ~%s coletadas'%(item.get('fruits'),item.get('steps'),item.get('collected',0)))
                if item.get('log'):self._log(item['message'])
                if item.get('position'):
                    x,y=item['position'];self.coordinates.set('Personagem x=%d / y=%d'%(x,y))
            elif kind=='error':
                self._log('SEGURANÇA: '+item['message'])
                self.status.set('Parado: '+item['message'][:94])
                self.pill.configure(text='●  ERRO / PARADO',fg=RED)
            elif kind=='stopped':
                self._log(item['message'])
                if not self.status.get().startswith('Parado:'):
                    self.status.set('PARADO • WASD liberadas')
                self.pill.configure(text='●  DESLIGADO',fg=SUB)
        self.root.after(75,self._tick)

    def _close(self):
        self._stop()
        self.root.after(220,self.root.destroy)

def main():
    root=tk.Tk()
    app=Application(root)
    root.protocol('WM_DELETE_WINDOW',app._close)
    root.mainloop()

if __name__=='__main__':main()
