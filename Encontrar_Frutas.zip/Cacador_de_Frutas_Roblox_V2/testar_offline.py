"""Nao usa teclado e nao altera o jogo."""
from pathlib import Path
import cv2
import numpy as np
from vision import Arena,FruitDetector,PlayerTracker,draw_overlay,select_target,choose_key,find_path

base=Path(__file__).resolve().parent
frame=cv2.imread(str(base/'exemplos'/'print_original.png'))
assert frame is not None
h,w=frame.shape[:2]
a=Arena([[685,282],[1275,282],[1330,880],[645,880]],[[[881,581],[1080,581],[1080,905],[881,905]]],34,w,h)
pos=(960,547)
assert a.contains(*pos),'Player fora da zona segura'
tracker=PlayerTracker(frame,pos)
tracked,confidence=tracker.locate(frame)
assert tracked is not None and confidence>.95
fruits=FruitDetector().detect(frame,a,pos)
assert len(fruits)>=10,'Detector encontrou poucas frutas: '+str(len(fruits))
target=select_target(a,pos,fruits)
assert target is not None, 'Nenhuma rota dentro do cercado'
f,path=target
assert all(a.contains(*point) for point in path)
assert a.line_is_safe(pos,path[1])
movement=choose_key(a,pos,path[1],(0,-190),(190,0),.1)
assert movement is not None and a.contains(*movement[1])
image=draw_overlay(frame,a,fruits,pos,f,path,'TESTE OFFLINE: '+str(len(fruits))+' FRUTAS')
file=base/'exemplos'/'teste_deteccao.png'
cv2.imwrite(str(file),image)
print('OK: '+str(len(fruits))+' frutas, jogador localizado, rota valida, WASD limitado.')
print('Imagem de teste em',file)
