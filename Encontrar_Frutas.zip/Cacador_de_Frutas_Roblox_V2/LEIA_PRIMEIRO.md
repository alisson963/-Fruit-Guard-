# 🍎 Fruit Guard V2 — movimento contínuo até as frutas

Aplicativo para Windows, experimental, com painel de INICIAR/PARAR e atalhos F6/F7/F8. Esta versão substitui a versão BETA que às vezes enviava um único `W` e parava. **Não é um script interno do jogo:** captura a tela e envia comandos WASD ao Roblox Player em primeiro plano.

## Correções da V2

- Movimentos de **até 275 ms por padrão**, ajustáveis de 150 a 420 ms; não depende de toques curtíssimos de 100 ms.
- Suporta **W+A, W+D, S+A e S+D** para ir diretamente na direção da maçã quando houver caminho livre.
- Faz uma captura **depois de cada movimento** para verificar a nova posição, recalcular o trajeto e decidir o próximo passo.
- Rastreador de personagem mais tolerante a mudanças de animação (usa vários padrões visuais e tenta novamente em até três capturas).
- Melhor acompanhamento quando a câmera se desloca: compara as **bordas** da arena, em vez de borrar a textura do chão, o que escondia o deslocamento.
- Mantém a mesma fruta como alvo durante a aproximação e escolhe outra quando a primeira some da proximidade do personagem.
- Continua evitando a cerca e a torre. Se um alvo estiver bloqueado, tenta outro, em vez de ficar repetindo eternamente a mesma tecla.
- Mensagens de diagnóstico mais específicas para caso o jogo não receba as teclas, o personagem fique fora da margem ou o rastreio falhe.
- Dois métodos de envio de WASD: **scan** (padrão) e **vk** (alternativa caso o Roblox ignore o primeiro).

## Instalação no Windows

1. Extraia o ZIP em uma **pasta nova**, sem misturar arquivos da BETA.
2. É necessário Python 3.11 ou 3.12. Abra `INSTALAR_E_ABRIR.bat` (a primeira execução instalará as dependências).
3. Depois, para abrir mais rápido, use `ABRIR.bat`.
4. O app não solicita senha nem acesso à conta Roblox.

## Antes de ligar

1. Abra o **Roblox Player no monitor principal**. Deixe a câmera em um ângulo estável, olhando de cima para a mesma área.
2. Coloque seu personagem em **uma parte aberta do cercado**, longe da torre e das paredes para que o teste de W/D tenha espaço.
3. Com o Roblox em primeiro plano, pressione **F6** para capturar a tela, sem mover o personagem depois disso.
4. Na janela do app, clique em **1. Cerca** e marque os quatro cantos internos; **2. Personagem** e clique no **centro do avatar**; **3. Obstáculo** e contorne a torre do Floor 542. Use **Limpar obstáculos** para apagar marcações antigas.
5. Mantenha a **margem de segurança** de 34 px ou aumente-a. Não reduza a margem só para chegar a uma fruta muito perto do muro.
6. Em MOVIMENTO E PROTEÇÕES, selecione **scan**, habilite **Calibrar WASD automaticamente**, e deixe o passo em **275 ms**.
7. Clique **Salvar calibração**. Volte ao Roblox e pressione **F7**. O bot mede W e D uma vez, volta com S e A, e então inicia a coleta contínua.
8. **F8** interrompe a qualquer momento e libera as teclas. Fechar o app também solicita a liberação.

> O botão INICIAR dentro da janela é útil para conferir configurações, mas a tecla F7 dentro do Roblox evita o problema de o jogo perder o foco para o aplicativo.

## Se continuar apertando apenas W

Olhe a seção **DIAGNÓSTICO** da interface:

- **`Perdi o personagem`**: a animação ou câmera mudou. Volte a uma área livre, pressione **F6**, marque novamente o personagem, salve e reinicie com F7.
- **`Tecla W nao moveu`**: experimente `vk` no campo **Teclado**, salve e reinicie. Se ambos forem ignorados, o Roblox pode estar bloqueando a entrada simulada; não há garantia de compatibilidade.
- **`Perto de obstaculo/cerca para calibrar`**: leve o avatar manualmente mais ao centro antes de F6.
- **`Roblox perdeu o foco`**: volte ao Roblox Player e use F7. O programa não tenta atuar em outras janelas.
- **`Nao ha passagem`**: confira as marcações de cerca/torre. Uma fruta pode estar dentro da região visível mas fora da margem segura.
- **`WASD quase iguais`**: fixe a câmera para o alto ou use outro ângulo e repita F6.

**Não desligue a calibração automática** a menos que seu Roblox esteja realmente configurado com `W = tela para cima` e `D = tela para a direita`. Caso contrário, ele pode andar na direção errada.

## Testes sem mexer no jogo

- `TESTAR_DETECCAO.bat`: valida as frutas e os percursos no print original.
- `TESTAR_MOVIMENTO_SEM_ROBLOX.bat`: simula WASD em uma arena virtual com o mesmo print e verifica se chega a várias frutas consecutivamente sem atravessar a cerca ou o obstáculo.
- `TESTAR_CAMERA_SEM_ROBLOX.bat`: desloca artificialmente o print e verifica o rastreio do deslocamento da câmera.

Esses testes **não apertam teclas no Roblox**. Na simulação local da V2, foram alcançadas 8 frutas em 20 movimentos planejados, sem cruzar a margem de segurança. O aplicativo Windows abriu em teste de interface, mas **os comandos reais ainda não foram testados em uma partida Roblox neste ambiente**.

## Limitações

O jogo pode bloquear SendInput, animações podem atrapalhar o rastreador, a câmera pode girar/zoomar ou obstáculos não marcados podem impedir a passagem. Não é possível garantir 100% que o avatar nunca ultrapasse o cercado; a segurança é estimada pela imagem. Supervisione os primeiros minutos e deixe F8 acessível. Confira também as regras do jogo sobre automação.
