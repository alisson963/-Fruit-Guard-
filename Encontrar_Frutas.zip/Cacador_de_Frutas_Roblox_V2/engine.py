"""Coleta por visao computacional, com correcoes de movimento a cada observacao.

Nao le nem injeta memoria de jogos. Envia WASD somente ao Roblox em primeiro plano.
O avatar nao se move se a deteccao ou a previsao de seguranca forem incertas.
"""
import math
import threading
import time

import cv2

from vision import (
    Arena, FruitDetector, PlayerTracker, SceneShift, choose_action,
    draw_overlay, find_path, select_target, waypoint,
)
from controller import GameKeys, Screen, ControlError


class Engine:
    def __init__(self, calibration, reference_frame, post, step=.26, auto_calibrate=True):
        self.config = calibration
        self.reference_frame = reference_frame
        self.post = post
        self.step = max(.11, min(.42, float(step)))
        self.auto_calibrate = auto_calibrate
        self.stop_event = threading.Event()
        self.thread = None
        self.nsteps = 0
        self.fruit_count = 0
        self.vw = None
        self.vd = None
        self.stuck = 0
        self.target = None
        self.blocked = []
        self.no_progress = 0

    def start(self):
        if self.thread is not None and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, name='fruit-guard-mover', daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def _emit(self, message, frame=None, fruits=(), player=None, target=None,
              path=None, log=False):
        self.post(dict(kind='state', message=message, steps=self.nsteps,
                       fruits=len(fruits), position=player, velocity=(self.vw, self.vd),
                       collected=self.fruit_count, log=log))
        if frame is not None:
            output = draw_overlay(frame, self.arena, fruits, player, target, path, message[:55])
            self.post(dict(kind='frame', frame=output))

    def _grab_update(self, attempts=3):
        """Se a sprite mudou de pose, repete a captura parada antes de desistir."""
        last_conf = 0.
        for attempt in range(attempts):
            if self.stop_event.is_set():
                raise ControlError('Interrompido pelo usuario (F8).')
            frame = self.screen.grab()
            self.arena.scale_to(frame.shape[1], frame.shape[0])
            shift, response = self.scene.update(frame, self.arena)
            if abs(shift[0]) > 100 or abs(shift[1]) > 100:
                raise ControlError('Camera se moveu muito; seguranca acionada.')
            self.arena.shift(*shift)
            # O avatar pode mudar de pose, logo um erro isolado nao encerra a coleta.
            pos, last_conf = self.tracker.locate(frame, expected_shift=shift,
                                                  search_radius=150 if attempt else 120)
            if pos is not None:
                if not self.arena.contains(*pos):
                    raise ControlError('Avatar fora da margem interna do cercado; parei.')
                return frame, pos, shift, last_conf
            if self.stop_event.wait(.055):
                raise ControlError('Interrompido pelo usuario (F8).')
        raise ControlError('Perdi o personagem apos 3 imagens (%.2f). '
                           'Pressione F6 e marque o avatar novamente.' % last_conf)

    def _move(self, keys, seconds):
        self.keys.press_combo(keys, seconds, self.stop_event)
        if self.stop_event.wait(.065):
            raise ControlError('Interrompido pelo usuario (F8).')
        return self._grab_update()

    @staticmethod
    def _relative_delta(before, after, scene_shift):
        return (after[0] - before[0] - scene_shift[0],
                after[1] - before[1] - scene_shift[1])

    def _calibrate_axis(self, key, reverse, original_guess):
        """Mede uma tecla a partir do movimento observado, testando 2 duracoes.

        O prototipo so fazia um toque minúsculo e travava se o jogo nao tivesse
        deslocado a sprite no mesmo frame. Retentamos de modo limitado.
        """
        movement = (0., 0.)
        durations = []
        for duration in (.18, .27):
            if self.stop_event.is_set():
                raise ControlError('Calibracao cancelada.')
            before = self.tracker.pos
            # Assume eixo alinhado APENAS para impedir mover rumo ao limite.
            estimate = (before[0] + original_guess[0]*duration,
                        before[1] + original_guess[1]*duration)
            if not self.arena.line_is_safe(before, estimate):
                raise ControlError('Avatar perto de obstaculo/cerca para calibrar %s. '
                                   'Coloque-o numa area aberta e tente F7.' % key)
            frame, after, shift, confidence = self._move((key,), duration)
            delta = self._relative_delta(before, after, shift)
            movement = (movement[0]+delta[0], movement[1]+delta[1])
            durations.append(duration)
            speed = math.hypot(*movement)/sum(durations)
            if speed >= 28.:
                break
            self._emit('Calibrando %s: movimento baixo, tentando toque maior...' % key,
                       frame, player=after, log=True)
        seconds = sum(durations)
        speed = math.hypot(*movement)/seconds
        if speed < 28:
            raise ControlError('Tecla %s nao moveu o avatar de forma mensuravel (%.0f px/s). '
                               'Confira foco do Roblox, selecione a camera fixa e '
                               'recalibre; se necessario desative Calibrar WASD.' % (key, speed))
        if speed > 1400:
            raise ControlError('Movimento %s muito grande; camera/rastreio instaveis.' % key)
        velocity = movement[0]/seconds, movement[1]/seconds
        self._emit('%s medido: %.0f px/s (%.0f, %.0f). Voltando com %s.' %
                   (key, speed, *velocity, reverse), frame, player=after, log=True)
        # Solta, anda de volta com a tecla oposta (tambem limitada pelo cercado).
        back = (after[0]-velocity[0]*seconds, after[1]-velocity[1]*seconds)
        if not self.arena.line_is_safe(after, back):
            raise ControlError('Nao consigo retornar do teste de %s sem cruzar limite.' % key)
        self._move((reverse,), seconds)
        return velocity

    def _calibrate(self):
        self._emit('Medindo W e D; use area aberta e nao mude a camera.', log=True)
        # O teste usa W e D e volta com S e A. A margem impede ir perto da cerca.
        self.vw = self._calibrate_axis('W', 'S', (0., -230.))
        self.vd = self._calibrate_axis('D', 'A', (230., 0.))
        unit = math.hypot(*self.vw)*math.hypot(*self.vd)
        determinant = self.vw[0]*self.vd[1]-self.vw[1]*self.vd[0]
        if unit < 1 or abs(determinant)/unit < .30:
            raise ControlError('W e D apontam para direcoes quase iguais. '
                               'Fixe a camera e tente a calibracao novamente.')
        self._emit('WASD calibrado: W=(%.0f, %.0f), D=(%.0f, %.0f)' %
                   (*self.vw, *self.vd), log=True)

    def _update_velocity(self, keys, duration, relative):
        """Corrige gradualmente a velocidade observada. Nao aprende com colisoes."""
        magnitude = math.hypot(*relative)/duration
        if not (35 < magnitude < 900) or len(keys) != 1:
            return
        key = keys[0]
        axis = 'vw' if key in ('W', 'S') else 'vd'
        sign = -1. if key in ('S', 'A') else 1.
        measured = relative[0]*sign/duration, relative[1]*sign/duration
        previous = getattr(self, axis)
        pmag = math.hypot(*previous)
        mmag = math.hypot(*measured)
        if pmag and (previous[0]*measured[0]+previous[1]*measured[1])/(pmag*mmag)<.70:
            return
        setattr(self, axis, (.83*previous[0]+.17*measured[0],
                             .83*previous[1]+.17*measured[1]))

    def _choose_target(self, pos, shift, fruits):
        """Preserva a fruta escolhida, em vez de trocar de alvo a cada frame."""
        now = time.monotonic()
        self.blocked = [((x+shift[0], y+shift[1]), until)
                        for ((x,y),until) in self.blocked if until>now]
        blocked_points = [pt for pt,until in self.blocked]
        if self.target is not None:
            self.target = (self.target[0]+shift[0], self.target[1]+shift[1])
            neighbors = [f for f in fruits if math.dist((f.x,f.y), self.target)<34]
            if neighbors:
                candidate = min(neighbors, key=lambda f:math.dist((f.x,f.y),self.target))
                if all(math.dist((candidate.x,candidate.y), p)>30 for p in blocked_points):
                    path = find_path(self.arena, pos, (candidate.x,candidate.y))
                    if path:
                        self.target = candidate.x, candidate.y
                        return candidate,path
            # Se sumiu quando avatar estava proximo, possivelmente foi coletada.
            if math.dist(pos,self.target)<52:
                self.fruit_count += 1
            self.target = None
            self.no_progress = 0
        result = select_target(self.arena, pos, fruits, ignore=blocked_points)
        if result:
            f,_ = result
            self.target = f.x, f.y
        return result

    def _mark_blocked(self, message):
        if self.target:
            self.blocked.append((self.target, time.monotonic()+7.))
        self.target = None
        self.no_progress = 0
        self.stuck = 0
        self._emit(message, log=True)

    def _run(self):
        self.keys=None
        self.screen=None
        try:
            self.keys=GameKeys(self.config.get('input_mode','scan'))
            ok, window = self.keys.roblox_foreground()
            if not ok:
                raise ControlError('Abra o Roblox Player e inicie com F7. Janela: '+window)
            self.screen=Screen()
            frame=self.screen.grab()
            h,w=frame.shape[:2]
            self.arena=Arena(self.config['polygon'], self.config.get('obstacles',[]),
                             self.config.get('margin',34),
                             self.config['width'], self.config['height'])
            self.arena.scale_to(w,h)
            ratio=(w/self.config['width'],h/self.config['height'])
            player=(self.config['player'][0]*ratio[0],self.config['player'][1]*ratio[1])
            rh,rw=self.reference_frame.shape[:2]
            if abs(rw/rh-w/h)>.03:
                raise ControlError('Proporcao diferente. Tire novo print com F6.')
            ref=(cv2.resize(self.reference_frame,(w,h),interpolation=cv2.INTER_LINEAR)
                 if (rw,rh)!=(w,h) else self.reference_frame)
            self.tracker=PlayerTracker(ref,player)
            pos,confidence=self.tracker.locate(frame,search_radius=135)
            if pos is None:
                raise ControlError('Avatar nao corresponde ao print (%.2f). '
                                   'Capture a tela atual com F6.' % confidence)
            if not self.arena.contains(*pos):
                raise ControlError('Avatar fora da zona segura. Recalibre o cercado.')
            self.scene=SceneShift()
            self.scene.update(frame,self.arena)
            self.detector=FruitDetector()
            self._emit('Avatar encontrado. Preparando movimentacao...', frame, player=pos, log=True)
            if self.auto_calibrate:
                self._calibrate()
            else:
                # Avanco conservador quando camera esta realmente alinhada ao print.
                self.vw=(0.,-220.)
                self.vd=(220.,0.)
                self._emit('Camera alinhada: W cima / D direita (sem calibracao).',log=True)

            self._emit('COLETANDO: movimento continuo e recalculo de rotas.', log=True)
            last_update=0.
            blocked_cycles=0
            while not self.stop_event.is_set():
                ok,window=self.keys.roblox_foreground()
                if not ok:
                    raise ControlError('Roblox perdeu o foco: '+window)
                frame,pos,shift,confidence=self._grab_update()
                fruits=self.detector.detect(frame,self.arena,pos)
                match=self._choose_target(pos,shift,fruits)
                if match is None:
                    if time.monotonic()-last_update>.65:
                        self._emit('Aguardando frutas dentro do cercado...',frame,fruits,pos)
                        last_update=time.monotonic()
                    if self.stop_event.wait(.16):break
                    continue
                fruit,path=match
                # A* guia em torno da torre, mas movimento direto em areas livres.
                goal=waypoint(path,pos,80)
                action=choose_action(self.arena,pos,goal,self.vw,self.vd,self.step)
                if action is None:
                    goal=waypoint(path,pos,32)
                    action=choose_action(self.arena,pos,goal,self.vw,self.vd,
                                         min(self.step,.14),min_dt=.055)
                if action is None:
                    self._mark_blocked('Sem passagem segura para uma fruta; procurando outra.')
                    if self.stop_event.wait(.1):break
                    continue
                keys,duration,prediction=action
                if not self.arena.line_is_safe(pos,prediction):
                    self._mark_blocked('Passo proximo do limite descartado.')
                    continue
                if time.monotonic()-last_update>.34:
                    self._emit('Indo ate a fruta %s: %s por %d ms' %
                               (fruit.kind,'+'.join(keys),round(duration*1000)),
                               frame,fruits,pos,fruit,path)
                    last_update=time.monotonic()
                before=pos
                # Uma unica captura apos o comando: o deslocamento nao pode ser
                # descartado por uma segunda captura da mesma posicao.
                moved_frame,after,shift2,conf2=self._move(keys,duration)
                self.nsteps+=1
                delta=self._relative_delta(before,after,shift2)
                displacement=math.hypot(*delta)
                self._update_velocity(keys,duration,delta)
                # Um comando curto sem movimento nao significa pane: tente novamente,
                # mas nao fique segurando W para sempre.
                if displacement<2.8:
                    self.stuck+=1
                    if self.stuck>=3:
                        blocked_cycles+=1
                        self._mark_blocked('Fruta inacessivel ou avatar bloqueado. Tentando outro alvo.')
                    if blocked_cycles>=4:
                        raise ControlError('Roblox nao esta aceitando os comandos WASD '
                                           'ou o rastreio nao esta acompanhando. '
                                           'Revise a camera e a calibracao, F6/F7.')
                else:
                    self.stuck=0
                    blocked_cycles=0
                if displacement>max(95,math.hypot(*self.vw)*duration*2.6,
                                    math.hypot(*self.vd)*duration*2.6):
                    raise ControlError('Salto inesperado de %.0f pixels; parada de seguranca.' % displacement)
                # Avalia progresso relativo ao alvo na arena transladada.
                new_target=(fruit.x+shift2[0], fruit.y+shift2[1])
                if self.target is not None:
                    self.target=(self.target[0]+shift2[0],self.target[1]+shift2[1])
                self.blocked=[((pt[0]+shift2[0],pt[1]+shift2[1]),until)
                              for pt,until in self.blocked]
                before_dist=math.dist(before,(fruit.x,fruit.y))
                after_dist=math.dist(after,new_target)
                if after_dist > before_dist-1.5 and displacement>2.8:
                    self.no_progress+=1
                else:
                    self.no_progress=0
                if self.no_progress>=7:
                    self._mark_blocked('Caminho sem progresso; selecionando outra fruta.')
        except ControlError as exc:
            if not self.stop_event.is_set():
                self.post({'kind':'error','message':str(exc)})
        except Exception as exc:
            self.post({'kind':'error','message':type(exc).__name__+': '+str(exc)})
        finally:
            if self.keys:
                try:self.keys.release_all()
                except Exception:pass
            if self.screen:
                try:self.screen.close()
                except Exception:pass
            self.post({'kind':'stopped','message':'Bot parado; WASD liberadas.'})
