@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    set "PY=python"
)
%PY% --version || (
 echo ERRO: Instale Python 3.11 ou 3.12 marcando "Add python.exe to PATH".
 pause
 exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
    %PY% -m venv .venv || (pause & exit /b 1)
)
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt || (pause & exit /b 1)
".venv\Scripts\python.exe" app.py
if errorlevel 1 pause
