"""Teste visual da camera SEM controle do Roblox."""
import cv2
import numpy as np
from pathlib import Path
from vision import Arena, SceneShift, PlayerTracker

image=cv2.imread(str(Path(__file__).parent/'exemplos'/'print_original.png'))
h,w=image.shape[:2]
assert image is not None
arena=Arena([[685,282],[1275,282],[1330,880],[645,880]],[],34,w,h)
scene=SceneShift()
scene.update(image,arena)
player=PlayerTracker(image,(960,547))
actual=(0,0)
for dx,dy in ((17,-11),(35,20),(-9,21)):
    changed=cv2.warpAffine(image,np.float32([[1,0,dx],[0,1,dy]]),(w,h))
    measured,confidence=scene.update(changed,arena)
    err=np.hypot(measured[0]-dx,measured[1]-dy)
    assert err<4.0,(measured,(dx,dy),confidence)
    position,pc=player.locate(changed,expected_shift=measured)
    assert position is not None and pc>.70,(position,pc)
    print('Camera dx=%+d dy=%+d -> estimado (%+.1f,%+.1f), confianca %.2f'%(dx,dy,*measured,confidence))
    image=changed
print('OK: deslocamento da camera detectado e personagem rastreado.')
