"""Captura e teclas apenas em janela verificada Roblox (Windows)."""
import ctypes
from ctypes import wintypes
import os
import time
import threading
import numpy as np
import cv2

class ControlError(RuntimeError):pass

class Screen:
    def __init__(self):
        try:
            import mss
        except ImportError as exc:
            raise ControlError('Instale as dependencias: pip install -r requirements.txt') from exc
        self.mss=mss.mss()
        self.monitor=self.mss.monitors[1]

    def grab(self):
        raw=self.mss.grab(self.monitor)
        return cv2.cvtColor(np.asarray(raw),cv2.COLOR_BGRA2BGR)

    def close(self):self.mss.close()

if os.name=='nt':
    user32=ctypes.windll.user32
    ULONG_PTR=ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p)==8 else ctypes.c_ulong
    class MOUSEINPUT(ctypes.Structure):
        _fields_=[('dx',wintypes.LONG),('dy',wintypes.LONG),('mouseData',wintypes.DWORD),('dwFlags',wintypes.DWORD),('time',wintypes.DWORD),('dwExtraInfo',ULONG_PTR)]
    class KEYBDINPUT(ctypes.Structure):
        _fields_=[('wVk',wintypes.WORD),('wScan',wintypes.WORD),('dwFlags',wintypes.DWORD),('time',wintypes.DWORD),('dwExtraInfo',ULONG_PTR)]
    class HARDWAREINPUT(ctypes.Structure):
        _fields_=[('uMsg',wintypes.DWORD),('wParamL',wintypes.WORD),('wParamH',wintypes.WORD)]
    class IUNION(ctypes.Union):
        _fields_=[('mi',MOUSEINPUT),('ki',KEYBDINPUT),('hi',HARDWAREINPUT)]
    class INPUT(ctypes.Structure):
        _fields_=[('type',wintypes.DWORD),('union',IUNION)]
    SCANS={'W':0x11,'A':0x1E,'S':0x1F,'D':0x20}
    user32.GetForegroundWindow.restype=wintypes.HWND
    user32.GetWindowTextLengthW.argtypes=(wintypes.HWND,)
    user32.GetWindowTextW.argtypes=(wintypes.HWND,wintypes.LPWSTR,ctypes.c_int)
    user32.GetWindowThreadProcessId.argtypes=(wintypes.HWND,ctypes.POINTER(wintypes.DWORD))
    user32.SendInput.argtypes=(wintypes.UINT,ctypes.POINTER(INPUT),ctypes.c_int)
    user32.SendInput.restype=wintypes.UINT
    user32.GetAsyncKeyState.argtypes=(ctypes.c_int,)
    user32.GetAsyncKeyState.restype=ctypes.c_short

class GameKeys:
    def __init__(self,mode='scan'):
        if os.name!='nt':raise ControlError('Controle automatico disponivel apenas no Windows.')
        self.down=set()
        self.mode=mode if mode in ('scan','vk') else 'scan'

    @staticmethod
    def roblox_foreground():
        import psutil
        hwnd=user32.GetForegroundWindow()
        if not hwnd:return False,'Nenhuma janela ativa'
        length=user32.GetWindowTextLengthW(hwnd)+1
        buff=ctypes.create_unicode_buffer(max(length,2))
        user32.GetWindowTextW(hwnd,buff,len(buff))
        pid=wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        try:process=psutil.Process(pid.value).name().lower()
        except Exception:process=''
        name=buff.value
        allow='robloxplayerbeta' in process or process in ('roblox.exe','robloxplayer.exe')
        return allow,(name+' ['+process+']')

    def _send(self,key,keyup):
        if key not in SCANS:raise ControlError('Tecla nao autorizada: '+str(key))
        flags=(0x0002 if keyup else 0)
        if self.mode=='scan':
            ki=KEYBDINPUT(0,SCANS[key],0x0008 | flags,0,0)
        else:
            ki=KEYBDINPUT(ord(key),0,flags,0,0)
        inp=INPUT(1,IUNION(ki=ki))
        sent=user32.SendInput(1,ctypes.byref(inp),ctypes.sizeof(INPUT))
        if sent!=1:raise ControlError('SendInput falhou; confira permissoes do Windows.')

    def release_all(self):
        for key in list(self.down):
            try:self._send(key,True)
            finally:self.down.discard(key)

    def press_combo(self,keys,duration,stop_event):
        """Mantem uma ou duas teclas de direcao realmente pressionadas.

        A versao anterior mandava toques de cerca de 100ms, curtos para alguns
        servidores Roblox. Este metodo segura as teclas, confere o foco e
        garante o keyup mesmo quando ha parada de emergencia.
        """
        keys=tuple(dict.fromkeys(keys))
        if not keys or any(k not in SCANS for k in keys) or len(keys)>2:
            raise ControlError('Combinacao WASD invalida: '+str(keys))
        if stop_event.is_set():return False
        ok,win=self.roblox_foreground()
        if not ok:raise ControlError('Roblox nao esta em primeiro plano: '+win)
        duration=max(.065,min(.55,float(duration)))
        try:
            for key in keys:
                self._send(key,False)
                self.down.add(key)
            finish=time.monotonic()+duration
            next_focus_check=time.monotonic()+.09
            while not stop_event.is_set() and time.monotonic()<finish:
                now=time.monotonic()
                if now>=next_focus_check:
                    ok,win=self.roblox_foreground()
                    if not ok:raise ControlError('Roblox perdeu o foco durante a caminhada: '+win)
                    next_focus_check=now+.09
                time.sleep(min(.018,max(.003,finish-time.monotonic())))
            return not stop_event.is_set()
        finally:
            self.release_all()

    def press(self,key,duration,stop_event):
        return self.press_combo((key,),duration,stop_event)

    @staticmethod
    def key_down(vk):
        return bool(user32.GetAsyncKeyState(vk)&0x8000)
