"""Simulacao SEM Roblox: verifica perseguicao de varias frutas e limites."""
from pathlib import Path
import cv2
import math
from vision import Arena, FruitDetector, select_target, waypoint, choose_action

root=Path(__file__).resolve().parent
frame=cv2.imread(str(root/'exemplos'/'print_original.png'))
h,w=frame.shape[:2]
arena=Arena([[685,282],[1275,282],[1330,880],[645,880]],
            [[[881,581],[1080,581],[1080,905],[881,905]]],34,w,h)
pos=(960.,547.)
fruits=FruitDetector().detect(frame,arena,pos)
collected=0
history=[]
current=None
for iteration in range(650):
    remaining=[f for f in fruits if math.dist(pos,(f.x,f.y))>28]
    if len(remaining)<len(fruits):
        collected+=len(fruits)-len(remaining)
        fruits=remaining
        current=None
    if not remaining or collected>=8: break
    candidates=remaining
    if current:
        candidates=sorted(remaining,key=lambda f:math.dist((f.x,f.y),current))
        if math.dist((candidates[0].x,candidates[0].y),current)>30:
            current=None
    if current:
        # Para seguir o alvo ate o final, sem trocar por outra fruta.
        f=candidates[0]
        from vision import find_path
        path=find_path(arena,pos,(f.x,f.y))
    else:
        target=select_target(arena,pos,remaining)
        assert target, f'Sem alvos, {collected} coletadas em {iteration} passos'
        f,path=target; current=f.x,f.y
    if not path:
        raise AssertionError(f'Perdeu caminho para {(f.x,f.y)} apos {iteration} passos')
    goal=waypoint(path,pos,80)
    move=choose_action(arena,pos,goal,(0.,-220.),(220.,0.),.275)
    if move is None:
        goal=waypoint(path,pos,32)
        move=choose_action(arena,pos,goal,(0.,-220.),(220.,0.),.14,min_dt=.055)
    assert move, f'Sem acao perto de {pos} indo a {(f.x,f.y)} em {iteration}'
    keys,dt,nextpos=move
    assert arena.line_is_safe(pos,nextpos), 'Passou do cercado ou obstaculo'
    history.append((tuple(keys),dt,math.dist(pos,(f.x,f.y))))
    pos=nextpos
print(f'OK: simulou {len(history)} movimentos, alcançou {collected} frutas consecutivas.')
print('Primeiras ações:', [("+".join(k),round(t,2)) for k,t,_ in history[:12]])
assert collected>=5, 'Esperava encontrar pelo menos 5 frutas no circuito'
assert any(len(keys)>1 for keys,_,_ in history), 'Não usou diagonais'
