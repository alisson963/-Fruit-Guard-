@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" testar_movimento.py
) else (
  py -3 testar_movimento.py
)
pause
